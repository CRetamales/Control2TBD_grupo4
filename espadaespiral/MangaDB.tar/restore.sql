--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10
-- Dumped by pg_dump version 12.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MangaDB";
--
-- Name: MangaDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MangaDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Chile.1252' LC_CTYPE = 'Spanish_Chile.1252';


ALTER DATABASE "MangaDB" OWNER TO postgres;

\connect "MangaDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: manga; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manga (
    id integer NOT NULL,
    nombremanga text NOT NULL,
    autormanga text NOT NULL,
    categoriamanga text NOT NULL,
    editorialmanga text NOT NULL,
    idiomamanga text NOT NULL,
    capitulomanga integer NOT NULL,
    numeropaginas integer NOT NULL,
    preciomanga integer NOT NULL
);


ALTER TABLE public.manga OWNER TO postgres;

--
-- Name: Manga_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Manga_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Manga_Id_seq" OWNER TO postgres;

--
-- Name: Manga_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Manga_Id_seq" OWNED BY public.manga.id;


--
-- Name: manga id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manga ALTER COLUMN id SET DEFAULT nextval('public."Manga_Id_seq"'::regclass);


--
-- Data for Name: manga; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manga (id, nombremanga, autormanga, categoriamanga, editorialmanga, idiomamanga, capitulomanga, numeropaginas, preciomanga) FROM stdin;
\.
COPY public.manga (id, nombremanga, autormanga, categoriamanga, editorialmanga, idiomamanga, capitulomanga, numeropaginas, preciomanga) FROM '$$PATH$$/2818.dat';

--
-- Name: Manga_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Manga_Id_seq"', 5, true);


--
-- Name: manga p_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manga
    ADD CONSTRAINT p_key PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

